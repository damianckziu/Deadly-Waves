extends Control

var font = preload("res://ka1.ttf")

const AVATARS = ["👤", "🐱", "🐶", "🐸", "👾", "🤖", "💀", "🦊"]
var selected_avatar = 0

func _ready():
	Global.load_profiles()
	_refresh_profiles()

func _refresh_profiles():
	var container = $ScrollContainer/ProfileContainer
	for child in container.get_children():
		child.queue_free()
	await get_tree().process_frame

	for i in range(Global.profiles.size()):
		var profile = Global.profiles[i]
		var card = _make_profile_card(profile, i)
		container.add_child(card)

	# Karta z plusem
	var add_card = _make_add_card()
	container.add_child(add_card)

func _make_profile_card(profile, index):
	var panel = PanelContainer.new()
	panel.custom_minimum_size = Vector2(150, 180)

	var vbox = VBoxContainer.new()
	panel.add_child(vbox)

	var avatar_label = Label.new()
	avatar_label.text = AVATARS[profile["avatar"]]
	avatar_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	avatar_label.add_theme_font_size_override("font_size", 40)
	vbox.add_child(avatar_label)

	var name_label = Label.new()
	name_label.text = profile["name"]
	name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_label.add_theme_font_override("font", font)
	vbox.add_child(name_label)

	var hs_label = Label.new()
	hs_label.text = "Rekord - " + str(int(profile["highscore"]))
	hs_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hs_label.add_theme_font_override("font", font)
	hs_label.add_theme_font_size_override("font_size", 12)
	vbox.add_child(hs_label)

	var games_label = Label.new()
	games_label.text = "Gry - " + str(int(profile["games_played"]))
	games_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	games_label.add_theme_font_override("font", font)
	games_label.add_theme_font_size_override("font_size", 12)
	vbox.add_child(games_label)

	var btn = Button.new()
	btn.text = "Graj"
	btn.add_theme_font_override("font", font)
	btn.pressed.connect(_select_profile.bind(index))
	vbox.add_child(btn)

	var del_btn = Button.new()
	del_btn.text = "Usun"
	del_btn.add_theme_font_override("font", font)
	del_btn.pressed.connect(_delete_profile.bind(index))
	vbox.add_child(del_btn)

	return panel

func _make_add_card():
	var panel = PanelContainer.new()
	panel.custom_minimum_size = Vector2(150, 180)

	var btn = Button.new()
	btn.text = "+"
	btn.add_theme_font_size_override("font_size", 48)
	btn.pressed.connect(_show_create_dialog)
	panel.add_child(btn)

	return panel

func _select_profile(index):
	Global.current_profile = index
	Global.highscore = Global.profiles[index]["highscore"]
	get_tree().change_scene_to_file("res://arena.tscn")

func _delete_profile(index):
	Global.profiles.remove_at(index)
	Global.save_profiles()
	_refresh_profiles()

func _show_create_dialog():
	$CreateDialog.visible = true
	$CreateDialog/VBox/NameInput.text = ""
	selected_avatar = 0
	_update_avatar_preview()

func _update_avatar_preview():
	$CreateDialog/VBox/AvatarBox/AvatarPreview.text = AVATARS[selected_avatar]

func _on_avatar_left_pressed():
	selected_avatar = (selected_avatar - 1 + AVATARS.size()) % AVATARS.size()
	_update_avatar_preview()

func _on_avatar_right_pressed():
	selected_avatar = (selected_avatar + 1) % AVATARS.size()
	_update_avatar_preview()

func _on_create_confirm_pressed():
	var name = $CreateDialog/VBox/NameInput.text.strip_edges()
	if name == "":
		return
	Global.create_profile(name, selected_avatar)
	$CreateDialog.visible = false
	_refresh_profiles()

func _on_create_cancel_pressed():
	$CreateDialog.visible = false

func _on_back_pressed():
	get_tree().change_scene_to_file("res://menu.tscn")
