extends Node
var node_creation_parent = null
var player = null
var arena = null
var points = 0
var highscore = 0

var profiles = []
var current_profile = -1

const SAVE_PATH = "user://profiles.json"

func save_profiles():
	var file = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	file.store_string(JSON.stringify(profiles))
	file.close()

func load_profiles():
	if not FileAccess.file_exists(SAVE_PATH):
		profiles = []
		return
	var file = FileAccess.open(SAVE_PATH, FileAccess.READ)
	var data = JSON.parse_string(file.get_as_text())
	file.close()
	if data != null:
		profiles = data

func create_profile(name: String, avatar: int):
	profiles.append({
		"name": name,
		"avatar": avatar,
		"highscore": 0,
		"games_played": 0
	})
	save_profiles()

func update_current_profile():
	if current_profile == -1:
		return
	if points > profiles[current_profile]["highscore"]:
		profiles[current_profile]["highscore"] = int(points)
	profiles[current_profile]["games_played"] = int(profiles[current_profile]["games_played"]) + 1
	save_profiles()

func instance_node(node, location, parent):
	var node_instance = node.instantiate()
	parent.add_child(node_instance)
	node_instance.global_position = location
	return node_instance
