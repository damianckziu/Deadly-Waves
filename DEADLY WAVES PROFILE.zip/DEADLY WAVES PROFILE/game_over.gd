extends Node2D
func _ready():
	Global.update_current_profile()

func _on_button_pressed():
	get_tree().change_scene_to_file("res://arena.tscn")
